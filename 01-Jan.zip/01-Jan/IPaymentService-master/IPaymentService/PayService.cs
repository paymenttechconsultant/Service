﻿using DependenyInjector;
using IPaymentService.Model;
using IPaymentService.ServiceUtil;
using Responses;
using System.Configuration;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace IPaymentService
{
    public class PayService : IPayService
    {
        private bool result = false;
        IConnection connection = DependencyInjector.Get<IConnection, Connection>();

        //IConnection con = new Connection();

        public bool CheckHeartBeat()
        {
            ResponseBase response = new ResponseBase();
            result = connection.CheckConnectionStatus(response);
            //result = true;
            return result;
        }

        public bool Connect(SocketConnectRequest connectRequest)
        {
            ResponseBase response = new ResponseBase();
            var hostaddress = $"{connectRequest.Host}:{connectRequest.Port}";
            //result = true;
            result = connection.Connect(hostaddress, response);
            return result;
        }
        public string XMLData(string id)
        {
            return Data(id);
        }
        public string JSONData(string id)
        {
            return Data(id);
        }

        private string Data(string id)
        {
            // logic
            return "Data: " + id;
        }
        //[HttpPost]
        //[Route("IPaymentService1/PaymentRequest")]
        //public bool PaymentRequest(PaymentRequest request, string member)
        //{
        //  //  return true;
        //    return connection.PayRequest(request, member);
        //}

        public bool PaymentRequest(PaymentRequest request, string member)
        {
            //  return true;

            SocketConnectRequest socketConnect = new SocketConnectRequest()
            {
                Port = int.Parse(ConfigurationManager.AppSettings["Port"]),           //2022      
            Host = ConfigurationManager.AppSettings["Host"]                // "192.168.50.29"

            };


            bool IsServerConnected = this.Connect(socketConnect);

            return connection.PayRequest(request, member);
        }

        //[HttpPost]
        //[Route("IPaymentService1/sample")]
        //public string SampleRequest(RequestData request)
        //{
        //    return "Simple Operation Result"+request.id;
        //}

        public string SimpleOperation()
        {
            return "Simple Operation Result";
        }

    }
}