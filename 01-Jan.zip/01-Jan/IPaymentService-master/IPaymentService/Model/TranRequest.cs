﻿using PaymentServiceLib.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace IPaymentService.Model
{
    [DataContract]
    public class TranRequest
    {

        [DataMember]
        public string TxnType { get; set; }

        [DataMember]
        public string AmtPurchase { get; set; }

        [DataMember]
        public string tenderType { get; set; }

        [DataMember]
        public string Invoice { get; set; }

        [DataMember]
        public string CustomerReference { get; set; }

    }
}
