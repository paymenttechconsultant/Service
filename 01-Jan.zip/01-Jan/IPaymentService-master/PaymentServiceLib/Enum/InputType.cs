﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentServiceLib.Enum
{
  
    public enum InputType { None = '0', Normal = '1', Amount = '2', Decimal = '3', Password = '4' }

}
