﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentServiceLib.Enum
{
    public enum ComPortSpeed { NoChange = ' ', Baud9600 = '0', Baud19200 = '1', Baud38400 = '2', Baud115200 = '3' }

}
