﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentServiceLib.Enum
{
    public enum KeyPressed { Enter = 'E', Cancel = 'C', Clear = 'B', ClearAll = 'D', Function = 'F', Alpha = 'A', Cheque = 'X', Savings = 'Y', Credit = 'Z', F0 = 'a', F1 = 'b', F2 = 'c', F3 = 'd', F4 = 'e', F5 = 'f', F6 = 'g', F7 = 'h', F8 = 'i', F9 = 'j', Zero = '0', One = '1', Two = '2', Three = '3', Four = '4', Five = '5', Six = '6', Seven = '7', Eight = '8', Nine = '9' }

}
